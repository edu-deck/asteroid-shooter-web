
import pygame
import random
import math
import os
import asyncio

# ============================================================
# ASTEROIDEN SHOOTER: GALAXY SURVIVAL
# Für Thonny + Pygame
#
# Steuerung:
# A / D oder Pfeiltasten = bewegen
# Leertaste halten = schießen
# Shift = Dash
# P = Pause
#
# Features:
# - Startmenü
# - Game Over mit Neustart
# - Highscore speichern
# - XP / Levelsystem
# - Münzen
# - Shop nach jedem Boss
# - mehrere Gegnertypen
# - Mini-Bosse
# - verschiedene Bosse
# - Power-ups und permanente Upgrades
# - Schild
# - seltene Herzen
# - bessere Grafik mit Glow, Sternen, Nebel und Explosionen
# ============================================================

pygame.init()

WIDTH, HEIGHT = 960, 680
FPS = 60

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Asteroiden Shooter: Galaxy Survival")
clock = pygame.time.Clock()

FONT = pygame.font.Font(None, 30)
FONT.set_bold(True)
SMALL_FONT = pygame.font.Font(None, 22)
SMALL_FONT.set_bold(True)
BIG_FONT = pygame.font.Font(None, 70)
BIG_FONT.set_bold(True)
TITLE_FONT = pygame.font.Font(None, 84)
TITLE_FONT.set_bold(True)

HIGH_SCORE_FILE = "galaxy_survival_highscore.txt"

WHITE = (255, 255, 255)
RED = (255, 60, 70)
GREEN = (80, 240, 120)
BLUE = (80, 180, 255)
CYAN = (40, 230, 255)
YELLOW = (255, 230, 90)
ORANGE = (255, 130, 30)
PURPLE = (180, 70, 255)
DARK = (3, 4, 16)

# ============================================================
# TOUCH-STEUERUNG (Smartphone)
# ============================================================
BTN_RADIUS = 55

TOUCH_BUTTONS = {
    "left":  (90, HEIGHT - 100),
    "right": (215, HEIGHT - 100),
    "dash":  (WIDTH - 215, HEIGHT - 100),
    "shoot": (WIDTH - 90, HEIGHT - 100),
}

PAUSE_BTN = pygame.Rect(WIDTH - 60, 15, 40, 40)

touch_controls = {"left": False, "right": False, "dash": False, "shoot": False}
active_pointers = {}  # Finger-ID bzw. "mouse" -> Button-Name

def button_at_pos(pos):
    x, y = pos
    for name, (cx, cy) in TOUCH_BUTTONS.items():
        if (x - cx) ** 2 + (y - cy) ** 2 <= BTN_RADIUS ** 2:
            return name
    return None

def handle_touch_event(event):
    """Wertet Finger- und Maus-Events aus und pflegt touch_controls."""
    if event.type == pygame.FINGERDOWN:
        pos = (event.x * WIDTH, event.y * HEIGHT)
        btn = button_at_pos(pos)
        if btn:
            active_pointers[event.finger_id] = btn
            touch_controls[btn] = True

    elif event.type == pygame.FINGERMOTION:
        pos = (event.x * WIDTH, event.y * HEIGHT)
        new_btn = button_at_pos(pos)
        old_btn = active_pointers.get(event.finger_id)
        if new_btn != old_btn:
            if old_btn:
                touch_controls[old_btn] = False
            if new_btn:
                touch_controls[new_btn] = True
            active_pointers[event.finger_id] = new_btn

    elif event.type == pygame.FINGERUP:
        btn = active_pointers.pop(event.finger_id, None)
        if btn:
            touch_controls[btn] = False

    elif event.type == pygame.MOUSEBUTTONDOWN:
        btn = button_at_pos(event.pos)
        if btn:
            active_pointers["mouse"] = btn
            touch_controls[btn] = True

    elif event.type == pygame.MOUSEBUTTONUP:
        btn = active_pointers.pop("mouse", None)
        if btn:
            touch_controls[btn] = False

def reset_touch_controls():
    for key in touch_controls:
        touch_controls[key] = False
    active_pointers.clear()

def draw_touch_controls():
    labels = {"left": "◀", "right": "▶", "dash": "DASH", "shoot": "FEUER"}
    for name, (cx, cy) in TOUCH_BUTTONS.items():
        pressed = touch_controls[name]
        color = (90, 210, 255, 0) if not pressed else (150, 240, 255, 0)
        surf = pygame.Surface((BTN_RADIUS * 2, BTN_RADIUS * 2), pygame.SRCALPHA)
        fill = (90, 210, 255, 90) if not pressed else (150, 240, 255, 150)
        pygame.draw.circle(surf, fill, (BTN_RADIUS, BTN_RADIUS), BTN_RADIUS)
        screen.blit(surf, (cx - BTN_RADIUS, cy - BTN_RADIUS))
        pygame.draw.circle(screen, WHITE, (cx, cy), BTN_RADIUS, 2)
        label = SMALL_FONT.render(labels[name], True, WHITE)
        screen.blit(label, (cx - label.get_width() // 2, cy - label.get_height() // 2))

    pygame.draw.rect(screen, (60, 60, 80, 120), PAUSE_BTN, border_radius=8)
    pygame.draw.rect(screen, WHITE, PAUSE_BTN, 2, border_radius=8)
    pause_label = SMALL_FONT.render("II", True, WHITE)
    screen.blit(pause_label, (PAUSE_BTN.centerx - pause_label.get_width() // 2, PAUSE_BTN.centery - pause_label.get_height() // 2))

def clamp(value, low, high):
    return max(low, min(high, value))

def load_highscore():
    if os.path.exists(HIGH_SCORE_FILE):
        try:
            with open(HIGH_SCORE_FILE, "r") as file:
                return int(file.read().strip())
        except:
            return 0
    return 0

def save_highscore(value):
    try:
        with open(HIGH_SCORE_FILE, "w") as file:
            file.write(str(value))
    except:
        pass

def draw_text_center(text, font, color, y):
    image = font.render(text, True, color)
    screen.blit(image, (WIDTH // 2 - image.get_width() // 2, y))

def draw_button(rect, text, mouse_pos):
    hover = rect.collidepoint(mouse_pos)
    color = (45, 170, 85) if not hover else (75, 230, 120)
    pygame.draw.rect(screen, color, rect, border_radius=14)
    pygame.draw.rect(screen, WHITE, rect, 3, border_radius=14)
    image = FONT.render(text, True, WHITE)
    screen.blit(image, (rect.centerx - image.get_width() // 2, rect.centery - image.get_height() // 2))
    return hover

def draw_glow(x, y, radius, color, layers=4):
    for i in range(layers, 0, -1):
        pygame.draw.circle(screen, color, (int(x), int(y)), radius + i * 5, 1)

class StarField:
    def __init__(self):
        self.stars = []
        for _ in range(220):
            self.stars.append({
                "x": random.randint(0, WIDTH),
                "y": random.randint(0, HEIGHT),
                "size": random.randint(1, 3),
                "speed": random.uniform(0.4, 3.2)
            })

    def update(self):
        for s in self.stars:
            s["y"] += s["speed"]
            if s["y"] > HEIGHT:
                s["x"] = random.randint(0, WIDTH)
                s["y"] = 0
                s["speed"] = random.uniform(0.4, 3.2)

    def draw(self):
        screen.fill(DARK)
        pygame.draw.circle(screen, (18, 20, 60), (130, 130), 210)
        pygame.draw.circle(screen, (20, 55, 85), (780, 230), 250)
        pygame.draw.circle(screen, (55, 18, 70), (460, 560), 280)
        pygame.draw.line(screen, (18, 48, 90), (0, 160), (WIDTH, 55), 2)
        pygame.draw.line(screen, (55, 24, 78), (0, 540), (WIDTH, 430), 2)

        for s in self.stars:
            b = random.randint(150, 255)
            pygame.draw.circle(screen, (b, b, 255), (int(s["x"]), int(s["y"])), s["size"])
            if s["size"] >= 3:
                pygame.draw.circle(screen, (90, 130, 255), (int(s["x"]), int(s["y"])), s["size"] + 4, 1)

class Particle:
    def __init__(self, x, y, color=None, speed_min=1, speed_max=6, life_min=18, life_max=45):
        angle = random.uniform(0, math.pi * 2)
        speed = random.uniform(speed_min, speed_max)
        self.x = x
        self.y = y
        self.dx = math.cos(angle) * speed
        self.dy = math.sin(angle) * speed
        self.life = random.randint(life_min, life_max)
        self.max_life = self.life
        self.size = random.randint(2, 5)
        self.color = color or (255, random.randint(90, 220), 0)

    def update(self):
        self.x += self.dx
        self.y += self.dy
        self.dy += 0.03
        self.life -= 1
        return self.life > 0

    def draw(self):
        pygame.draw.circle(screen, self.color, (int(self.x), int(self.y)), self.size)

class FloatingText:
    def __init__(self, text, x, y, color=WHITE):
        self.text = text
        self.x = x
        self.y = y
        self.life = 110
        self.color = color

    def update(self):
        self.y -= 0.6
        self.life -= 1
        return self.life > 0

    def draw(self):
        image = FONT.render(self.text, True, self.color)
        screen.blit(image, (self.x - image.get_width() // 2, self.y))

class Player:
    def __init__(self):
        self.rect = pygame.Rect(WIDTH // 2 - 25, HEIGHT - 100, 50, 66)
        self.base_speed = 10
        self.speed_bonus = 0
        self.lives = 5
        self.max_lives = 5
        self.shield = False
        self.shield_time = 0
        self.last_dash = 0
        self.invincible = 0

    @property
    def speed(self):
        return self.base_speed + self.speed_bonus

    def update(self, controls, now, particles):
        if controls["left"]:
            self.rect.x -= self.speed
        if controls["right"]:
            self.rect.x += self.speed

        if controls["dash"]:
            if now - self.last_dash > 900:
                if controls["left"]:
                    self.rect.x -= 110
                elif controls["right"]:
                    self.rect.x += 110
                self.last_dash = now
                for _ in range(18):
                    particles.append(Particle(self.rect.centerx, self.rect.centery, BLUE, 1, 5, 12, 24))

        self.rect.x = clamp(self.rect.x, 0, WIDTH - self.rect.width)

        if self.shield:
            self.shield_time -= 1
            if self.shield_time <= 0:
                self.shield = False

        if self.invincible > 0:
            self.invincible -= 1

    def damage(self, particles):
        if self.invincible > 0:
            return

        if self.shield:
            self.shield = False
            self.shield_time = 0
            for _ in range(25):
                particles.append(Particle(self.rect.centerx, self.rect.centery, BLUE))
        else:
            self.lives -= 1
            self.invincible = 70
            for _ in range(40):
                particles.append(Particle(self.rect.centerx, self.rect.centery))

    def heal(self, amount=1):
        self.lives = min(self.max_lives, self.lives + amount)

    def draw(self):
        x, y = self.rect.centerx, self.rect.centery
        flame = random.randint(16, 35)

        if self.shield:
            draw_glow(x, y, 48, BLUE, 5)
            pygame.draw.circle(screen, (90, 210, 255), (x, y), 49, 3)

        if self.invincible > 0 and self.invincible % 8 < 4:
            return

        pygame.draw.polygon(screen, ORANGE, [(x - 16, self.rect.bottom - 5), (x + 16, self.rect.bottom - 5), (x, self.rect.bottom + flame)])
        pygame.draw.polygon(screen, YELLOW, [(x - 7, self.rect.bottom - 2), (x + 7, self.rect.bottom - 2), (x, self.rect.bottom + flame // 2)])

        pygame.draw.polygon(screen, CYAN, [
            (x, self.rect.top),
            (self.rect.left - 7, self.rect.bottom - 4),
            (x - 14, self.rect.bottom - 16),
            (x + 14, self.rect.bottom - 16),
            (self.rect.right + 7, self.rect.bottom - 4)
        ])
        pygame.draw.polygon(screen, (0, 110, 190), [
            (x, self.rect.top + 18),
            (x - 19, self.rect.bottom - 12),
            (x + 19, self.rect.bottom - 12)
        ])
        pygame.draw.circle(screen, (240, 255, 255), (x, y), 10)
        pygame.draw.circle(screen, (70, 180, 255), (x, y), 10, 3)
        pygame.draw.line(screen, WHITE, (x - 8, y - 8), (x - 2, y - 2), 2)

class Bullet:
    def __init__(self, x, y, big=False, bounce=False, dx=0):
        self.rect = pygame.Rect(x, y, 16 if big else 8, 34 if big else 24)
        self.speed = 13
        self.big = big
        self.dx = dx
        self.bounces = 3 if bounce else 0
        self.bounce = bounce
        self.damage = 2 if big else 1

    def update(self):
        self.rect.y -= self.speed
        self.rect.x += self.dx

        if self.bounce and (self.rect.left <= 0 or self.rect.right >= WIDTH):
            self.dx *= -1
            self.bounces -= 1

        return self.rect.bottom > 0 and self.bounces >= 0

    def draw(self):
        draw_glow(self.rect.centerx, self.rect.centery, 8 if self.big else 5, ORANGE, 3)
        if self.big:
            pygame.draw.ellipse(screen, YELLOW, self.rect)
            pygame.draw.ellipse(screen, ORANGE, self.rect, 3)
        else:
            pygame.draw.rect(screen, YELLOW, self.rect, border_radius=4)
            pygame.draw.rect(screen, ORANGE, self.rect, 2, border_radius=4)

class EnemyBullet:
    def __init__(self, x, y, dx=0, dy=6, size=12):
        self.rect = pygame.Rect(x - size // 2, y, size, size * 2)
        self.dx = dx
        self.dy = dy

    def update(self):
        self.rect.x += self.dx
        self.rect.y += self.dy
        return self.rect.top < HEIGHT and self.rect.right > 0 and self.rect.left < WIDTH

    def draw(self):
        draw_glow(self.rect.centerx, self.rect.centery, 8, RED, 3)
        pygame.draw.ellipse(screen, RED, self.rect)
        pygame.draw.ellipse(screen, (255, 180, 180), self.rect, 2)

class Asteroid:
    def __init__(self, difficulty):
        size = random.randint(34, 78)
        self.rect = pygame.Rect(random.randint(0, WIDTH - size), -size, size, size)
        self.speed = random.uniform(1.0, 2.0) + difficulty * 0.12
        self.hp = 1
        self.value = 1

    def update(self):
        self.rect.y += self.speed
        return self.rect.top < HEIGHT

    def draw(self):
        r = self.rect
        pygame.draw.ellipse(screen, (135, 125, 115), r)
        pygame.draw.ellipse(screen, (70, 70, 78), r, 4)
        pygame.draw.arc(screen, (185, 175, 160), r, 3.8, 5.2, 3)
        for cx, cy, size in [(0.28, 0.34, 8), (0.58, 0.45, 6), (0.72, 0.70, 9), (0.42, 0.74, 5)]:
            pos = (int(r.x + r.width * cx), int(r.y + r.height * cy))
            radius = max(3, int(size * r.width / 60))
            pygame.draw.circle(screen, (45, 45, 52), pos, radius)
            pygame.draw.circle(screen, (95, 95, 105), pos, radius, 1)

class ScoutEnemy:
    def __init__(self, difficulty):
        self.rect = pygame.Rect(random.randint(20, WIDTH - 60), -50, 44, 36)
        self.speed = 2.0 + difficulty * 0.12
        self.hp = 1
        self.value = 2
        self.x_phase = random.random() * 6.28

    def update(self):
        self.rect.y += self.speed
        self.rect.x += math.sin(pygame.time.get_ticks() / 220 + self.x_phase) * 2.0
        return self.rect.top < HEIGHT

    def draw(self):
        r = self.rect
        pygame.draw.polygon(screen, (255, 80, 110), [(r.centerx, r.bottom), (r.left, r.top + 8), (r.right, r.top + 8)])
        pygame.draw.circle(screen, (255, 230, 230), (r.centerx, r.centery), 6)

class TankEnemy:
    def __init__(self, difficulty):
        self.rect = pygame.Rect(random.randint(30, WIDTH - 90), -70, 66, 52)
        self.speed = 1.0 + difficulty * 0.08
        self.hp = 3 + difficulty // 4
        self.value = 4

    def update(self):
        self.rect.y += self.speed
        return self.rect.top < HEIGHT

    def draw(self):
        r = self.rect
        pygame.draw.rect(screen, (190, 90, 50), r, border_radius=12)
        pygame.draw.rect(screen, (255, 200, 140), r, 3, border_radius=12)
        pygame.draw.circle(screen, RED, (r.centerx, r.centery), 10)

class ShooterEnemy:
    def __init__(self, difficulty):
        self.rect = pygame.Rect(random.randint(30, WIDTH - 80), -60, 58, 44)
        self.speed = 1.4 + difficulty * 0.08
        self.hp = 2
        self.value = 3
        self.timer = random.randint(0, 80)

    def update(self):
        self.rect.y += self.speed
        self.timer += 1
        return self.rect.top < HEIGHT

    def ready_to_shoot(self, difficulty):
        limit = max(60, 130 - difficulty * 4)
        if self.timer >= limit:
            self.timer = 0
            return True
        return False

    def draw(self):
        r = self.rect
        pygame.draw.polygon(screen, (80, 200, 255), [(r.left, r.top), (r.right, r.top), (r.centerx, r.bottom)])
        pygame.draw.circle(screen, (255, 240, 120), (r.centerx, r.centery), 8)

class MiniBoss:
    def __init__(self, difficulty):
        self.rect = pygame.Rect(WIDTH // 2 - 70, -90, 140, 70)
        self.speed = 1.4
        self.hp = 18 + difficulty * 4
        self.max_hp = self.hp
        self.value = 15
        self.direction = random.choice([-1, 1])
        self.timer = 0

    def update(self):
        if self.rect.y < 90:
            self.rect.y += self.speed
        else:
            self.rect.x += self.direction * 3
            if self.rect.left < 0 or self.rect.right > WIDTH:
                self.direction *= -1
        self.timer += 1
        return True

    def ready_to_shoot(self, difficulty):
        limit = max(45, 95 - difficulty * 3)
        if self.timer >= limit:
            self.timer = 0
            return True
        return False

    def draw(self):
        r = self.rect
        draw_glow(r.centerx, r.centery, 45, PURPLE, 3)
        pygame.draw.rect(screen, PURPLE, r, border_radius=16)
        pygame.draw.rect(screen, WHITE, r, 3, border_radius=16)
        pygame.draw.circle(screen, RED, (r.left + 35, r.centery), 12)
        pygame.draw.circle(screen, RED, (r.right - 35, r.centery), 12)

        bar_w = 140
        x = r.centerx - bar_w // 2
        y = r.top - 12
        pygame.draw.rect(screen, (80, 0, 0), (x, y, bar_w, 7))
        pygame.draw.rect(screen, RED, (x, y, int(bar_w * self.hp / self.max_hp), 7))

class Boss:
    def __init__(self, boss_level):
        types = ["Zerstörer", "Laser-Drohne", "Panzerkreuzer", "Kometenkönig", "Sternenlord"]
        self.name = types[(boss_level - 1) % len(types)]
        self.level = boss_level

        if self.name == "Zerstörer":
            hp, speed, color, delay = 40 + boss_level * 12, 3.2, (150, 30, 190), 65
        elif self.name == "Laser-Drohne":
            hp, speed, color, delay = 32 + boss_level * 10, 4.6, (30, 150, 230), 43
        elif self.name == "Panzerkreuzer":
            hp, speed, color, delay = 62 + boss_level * 16, 2.4, (210, 90, 45), 78
        elif self.name == "Kometenkönig":
            hp, speed, color, delay = 48 + boss_level * 14, 3.8, (60, 220, 120), 54
        else:
            hp, speed, color, delay = 80 + boss_level * 20, 3.3, (240, 210, 70), 38

        self.rect = pygame.Rect(WIDTH // 2 - 115, 60, 230, 100)
        self.hp = hp
        self.max_hp = hp
        self.speed = speed + boss_level * 0.16
        self.color = color
        self.shot_delay = delay
        self.direction = 1
        self.timer = 0

    def update(self, difficulty):
        self.rect.x += self.speed * self.direction
        if self.rect.left <= 0 or self.rect.right >= WIDTH:
            self.direction *= -1
        self.timer += 1

    def ready_to_shoot(self, difficulty):
        limit = max(22, self.shot_delay - difficulty * 2)
        if self.timer >= limit:
            self.timer = 0
            return True
        return False

    def shoot_pattern(self):
        shots = []
        if self.name == "Laser-Drohne":
            xs = [self.rect.left + 50, self.rect.centerx, self.rect.right - 50]
            for x in xs:
                shots.append(EnemyBullet(x, self.rect.bottom, 0, 6, 12))
        elif self.name == "Panzerkreuzer":
            for x in [self.rect.left + 50, self.rect.right - 50]:
                shots.append(EnemyBullet(x, self.rect.bottom, 0, 5, 16))
        elif self.name == "Kometenkönig":
            for dx in [-2, 0, 2]:
                shots.append(EnemyBullet(self.rect.centerx, self.rect.bottom, dx, 6, 12))
        elif self.name == "Sternenlord":
            for dx in [-3, -1.5, 0, 1.5, 3]:
                shots.append(EnemyBullet(self.rect.centerx, self.rect.bottom, dx, 6, 12))
        else:
            shots.append(EnemyBullet(self.rect.centerx, self.rect.bottom, 0, 6, 12))
        return shots

    def draw(self):
        r = self.rect
        draw_glow(r.centerx, r.centery, 85, self.color, 5)
        pygame.draw.rect(screen, self.color, r, border_radius=22)
        pygame.draw.rect(screen, WHITE, r, 4, border_radius=22)
        pygame.draw.rect(screen, (25, 25, 45), (r.left + 25, r.top + 20, r.width - 50, 38), border_radius=12)
        pygame.draw.circle(screen, RED, (r.left + 55, r.centery), 18)
        pygame.draw.circle(screen, RED, (r.right - 55, r.centery), 18)
        pygame.draw.circle(screen, (255, 220, 220), (r.left + 55, r.centery), 7)
        pygame.draw.circle(screen, (255, 220, 220), (r.right - 55, r.centery), 7)
        pygame.draw.rect(screen, (15, 15, 30), (r.left + 70, r.bottom - 22, 90, 14), border_radius=6)
        pygame.draw.rect(screen, ORANGE, (r.left + 88, r.bottom - 18, 54, 6), border_radius=3)

        hp_width = 380
        hp_x = WIDTH // 2 - hp_width // 2
        pygame.draw.rect(screen, (80, 0, 0), (hp_x, 15, hp_width, 19), border_radius=6)
        current = int(hp_width * self.hp / self.max_hp)
        pygame.draw.rect(screen, RED, (hp_x, 15, current, 19), border_radius=6)
        pygame.draw.rect(screen, WHITE, (hp_x, 15, hp_width, 19), 2, border_radius=6)

        name = FONT.render(f"{self.name}  Stufe {self.level}", True, WHITE)
        screen.blit(name, (WIDTH // 2 - name.get_width() // 2, 38))

class Item:
    def __init__(self, x, y, kind):
        self.kind = kind
        self.rect = pygame.Rect(x - 16, y - 16, 32, 32)
        self.speed = 2.2

    def update(self):
        self.rect.y += self.speed
        return self.rect.top < HEIGHT

    def draw(self):
        r = self.rect
        if self.kind == "heart":
            img = FONT.render("♥", True, RED)
            screen.blit(img, (r.x + 4, r.y - 2))
        elif self.kind == "coin":
            draw_glow(r.centerx, r.centery, 10, YELLOW, 2)
            pygame.draw.circle(screen, YELLOW, r.center, 12)
            pygame.draw.circle(screen, ORANGE, r.center, 12, 3)
        elif self.kind == "xp":
            pygame.draw.circle(screen, GREEN, r.center, 9)
            pygame.draw.circle(screen, WHITE, r.center, 9, 2)
        else:
            draw_glow(r.centerx, r.centery, 13, BLUE, 3)
            pygame.draw.circle(screen, BLUE, r.center, 15, 3)
            pygame.draw.circle(screen, (160, 230, 255), r.center, 7)

class Game:
    def __init__(self):
        self.starfield = StarField()
        self.reset_all()

    def reset_all(self):
        self.player = Player()
        self.bullets = []
        self.enemy_bullets = []
        self.enemies = []
        self.particles = []
        self.items = []
        self.texts = []
        self.score = 0
        self.coins = 0
        self.xp = 0
        self.xp_needed = 20
        self.level = 1
        self.difficulty = 1
        self.highscore = load_highscore()
        self.next_boss_score = 50
        self.next_miniboss_score = 30
        self.boss = None
        self.spawn_timer = 0
        self.last_shot = 0
        self.shoot_delay = 140
        self.double_shot = False
        self.big_shots = False
        self.bounce_shots = False
        self.triple_shot = False
        self.shop_open = False
        self.paused = False
        self.wave = 1

    def spawn_enemy(self):
        roll = random.random()
        if self.difficulty < 3:
            roll += 0.15

        if roll < 0.46:
            self.enemies.append(Asteroid(self.difficulty))
        elif roll < 0.68:
            self.enemies.append(ScoutEnemy(self.difficulty))
        elif roll < 0.84:
            self.enemies.append(ShooterEnemy(self.difficulty))
        else:
            self.enemies.append(TankEnemy(self.difficulty))

    def spawn_drops(self, x, y, value=1):
        if random.random() < 0.55:
            self.items.append(Item(x + random.randint(-10, 10), y, "xp"))
        if random.random() < 0.35:
            self.items.append(Item(x + random.randint(-10, 10), y, "coin"))
        if random.random() < 0.018:
            self.items.append(Item(x, y, "heart"))
        if random.random() < 0.04:
            self.items.append(Item(x, y, "shield"))

    def create_explosion(self, x, y, amount=30):
        for _ in range(amount):
            self.particles.append(Particle(x, y))

    def shoot(self, now):
        if now - self.last_shot < self.shoot_delay:
            return
        self.last_shot = now

        width = 16 if self.big_shots else 8
        offsets = [0]
        if self.double_shot:
            offsets = [-18, 18]
        if self.triple_shot:
            offsets = [-24, 0, 24]

        for off in offsets:
            dx = random.choice([-3, 3]) if self.bounce_shots else 0
            b = Bullet(self.player.rect.centerx + off - width // 2, self.player.rect.top - 12, self.big_shots, self.bounce_shots, dx)
            self.bullets.append(b)

    def gain_xp(self, amount):
        self.xp += amount
        while self.xp >= self.xp_needed:
            self.xp -= self.xp_needed
            self.level += 1
            self.xp_needed = int(self.xp_needed * 1.25 + 8)
            self.random_level_upgrade()
            self.texts.append(FloatingText("LEVEL UP!", WIDTH // 2, HEIGHT // 2, GREEN))

    def random_level_upgrade(self):
        choices = ["shoot", "speed", "max_life", "shield"]
        choice = random.choice(choices)
        if choice == "shoot":
            self.shoot_delay = max(65, self.shoot_delay - 10)
            self.texts.append(FloatingText("Upgrade: schneller schießen", WIDTH // 2, HEIGHT // 2 + 35, YELLOW))
        elif choice == "speed":
            self.player.speed_bonus = min(10, self.player.speed_bonus + 1)
            self.texts.append(FloatingText("Upgrade: schnelleres Schiff", WIDTH // 2, HEIGHT // 2 + 35, YELLOW))
        elif choice == "max_life":
            self.player.max_lives = min(8, self.player.max_lives + 1)
            self.player.heal(1)
            self.texts.append(FloatingText("Upgrade: mehr Leben", WIDTH // 2, HEIGHT // 2 + 35, YELLOW))
        else:
            self.player.shield = True
            self.player.shield_time = 600
            self.texts.append(FloatingText("Upgrade: Schild", WIDTH // 2, HEIGHT // 2 + 35, YELLOW))

    def boss_reward(self):
        self.score += 15
        self.coins += 8 + self.difficulty
        self.player.heal(1)
        self.gain_xp(12)
        self.give_powerup()
        self.shop_open = True

    def give_powerup(self):
        choices = ["speed", "shoot", "shield"]
        if not self.double_shot:
            choices.append("double")
        if not self.big_shots:
            choices.append("big")
        if not self.bounce_shots:
            choices.append("bounce")
        if not self.triple_shot and self.double_shot:
            choices.append("triple")

        power = random.choice(choices)

        if power == "double":
            self.double_shot = True
            text = "POWER-UP: Doppelschuss"
        elif power == "big":
            self.big_shots = True
            text = "POWER-UP: große Schüsse"
        elif power == "bounce":
            self.bounce_shots = True
            text = "POWER-UP: Bounce-Schüsse"
        elif power == "triple":
            self.triple_shot = True
            text = "POWER-UP: Dreifachschuss"
        elif power == "shoot":
            self.shoot_delay = max(60, self.shoot_delay - 20)
            text = "POWER-UP: schneller schießen"
        elif power == "speed":
            self.player.speed_bonus = min(10, self.player.speed_bonus + 2)
            text = "POWER-UP: schnelleres Schiff"
        else:
            self.player.shield = True
            self.player.shield_time = 700
            text = "POWER-UP: Schild"

        self.texts.append(FloatingText(text, WIDTH // 2, HEIGHT // 2, GREEN))

    def update(self):
        now = pygame.time.get_ticks()
        keys = pygame.key.get_pressed()

        controls = {
            "left": keys[pygame.K_a] or keys[pygame.K_LEFT] or touch_controls["left"],
            "right": keys[pygame.K_d] or keys[pygame.K_RIGHT] or touch_controls["right"],
            "dash": keys[pygame.K_LSHIFT] or keys[pygame.K_RSHIFT] or touch_controls["dash"],
            "shoot": keys[pygame.K_SPACE] or touch_controls["shoot"],
        }

        self.starfield.update()
        self.difficulty = 1 + self.score // 25

        self.player.update(controls, now, self.particles)

        if controls["shoot"]:
            self.shoot(now)

        if self.boss is None and self.score >= self.next_boss_score:
            level = self.next_boss_score // 50
            self.boss = Boss(level)
            self.enemies.clear()
            self.enemy_bullets.clear()
            self.next_boss_score += 50

        if self.boss is None and self.score >= self.next_miniboss_score:
            self.enemies.append(MiniBoss(self.difficulty))
            self.next_miniboss_score += 45

        self.spawn_timer += 1
        spawn_limit = max(18, 58 - self.difficulty * 3)
        if self.boss is None and self.spawn_timer >= spawn_limit:
            self.spawn_enemy()
            self.spawn_timer = 0

        self.bullets = [b for b in self.bullets if b.update()]
        self.enemy_bullets = [b for b in self.enemy_bullets if b.update()]
        self.particles = [p for p in self.particles if p.update()]
        self.texts = [t for t in self.texts if t.update()]
        self.items = [i for i in self.items if i.update()]

        for enemy in self.enemies[:]:
            alive_screen = enemy.update()
            if not alive_screen:
                self.enemies.remove(enemy)
                self.player.damage(self.particles)
                continue

            if hasattr(enemy, "ready_to_shoot") and enemy.ready_to_shoot(self.difficulty):
                if isinstance(enemy, MiniBoss):
                    self.enemy_bullets.append(EnemyBullet(enemy.rect.left + 35, enemy.rect.bottom, -1, 6, 12))
                    self.enemy_bullets.append(EnemyBullet(enemy.rect.right - 35, enemy.rect.bottom, 1, 6, 12))
                else:
                    self.enemy_bullets.append(EnemyBullet(enemy.rect.centerx, enemy.rect.bottom, 0, 6, 12))

            if enemy.rect.colliderect(self.player.rect):
                self.create_explosion(enemy.rect.centerx, enemy.rect.centery, 35)
                self.enemies.remove(enemy)
                self.player.damage(self.particles)

        if self.boss:
            self.boss.update(self.difficulty)
            if self.boss.ready_to_shoot(self.difficulty):
                self.enemy_bullets.extend(self.boss.shoot_pattern())
            if self.boss.rect.colliderect(self.player.rect):
                self.player.damage(self.particles)
                self.player.rect.centerx = WIDTH // 2

        for bullet in self.enemy_bullets[:]:
            if bullet.rect.colliderect(self.player.rect):
                self.enemy_bullets.remove(bullet)
                self.player.damage(self.particles)

        for item in self.items[:]:
            if item.rect.colliderect(self.player.rect):
                if item.kind == "heart":
                    self.player.heal(1)
                    self.texts.append(FloatingText("+1 Leben", self.player.rect.centerx, self.player.rect.y, RED))
                elif item.kind == "coin":
                    self.coins += 1
                elif item.kind == "xp":
                    self.gain_xp(2)
                elif item.kind == "shield":
                    self.player.shield = True
                    self.player.shield_time = 600
                    self.texts.append(FloatingText("Schild!", self.player.rect.centerx, self.player.rect.y, BLUE))
                self.items.remove(item)

        for bullet in self.bullets[:]:
            hit_done = False

            for enemy in self.enemies[:]:
                if bullet.rect.colliderect(enemy.rect):
                    if bullet in self.bullets:
                        self.bullets.remove(bullet)
                    enemy.hp -= bullet.damage
                    self.create_explosion(bullet.rect.centerx, bullet.rect.centery, 6)

                    if enemy.hp <= 0:
                        self.score += enemy.value
                        self.coins += 1 if random.random() < 0.35 else 0
                        self.gain_xp(enemy.value)
                        self.spawn_drops(enemy.rect.centerx, enemy.rect.centery, enemy.value)
                        self.create_explosion(enemy.rect.centerx, enemy.rect.centery, 28)
                        if enemy in self.enemies:
                            self.enemies.remove(enemy)
                    hit_done = True
                    break

            if hit_done:
                continue

            if self.boss and bullet.rect.colliderect(self.boss.rect):
                if bullet in self.bullets:
                    self.bullets.remove(bullet)
                self.boss.hp -= bullet.damage
                self.create_explosion(bullet.rect.centerx, bullet.rect.centery, 8)

                if self.boss.hp <= 0:
                    self.create_explosion(self.boss.rect.centerx, self.boss.rect.centery, 130)
                    self.boss = None
                    self.enemy_bullets.clear()
                    self.boss_reward()

        if self.score > self.highscore:
            self.highscore = self.score
            save_highscore(self.highscore)

    def draw_ui(self):
        hearts = "♥" * self.player.lives
        img = FONT.render(hearts, True, RED)
        screen.blit(img, (20, 15))

        dash = SMALL_FONT.render("A/D bewegen | Leertaste schießen | Shift Dash | P Pause", True, (180, 220, 255))
        screen.blit(dash, (20, 49))

        xp_w = 220
        xp_x = 20
        xp_y = 78
        pygame.draw.rect(screen, (20, 60, 35), (xp_x, xp_y, xp_w, 12), border_radius=4)
        pygame.draw.rect(screen, GREEN, (xp_x, xp_y, int(xp_w * self.xp / self.xp_needed), 12), border_radius=4)
        pygame.draw.rect(screen, WHITE, (xp_x, xp_y, xp_w, 12), 1, border_radius=4)
        xp_text = SMALL_FONT.render(f"Level {self.level}", True, WHITE)
        screen.blit(xp_text, (xp_x + xp_w + 8, xp_y - 5))

        texts = [
            f"Punkte: {self.score}",
            f"Highscore: {self.highscore}",
            f"Münzen: {self.coins}",
            f"Schwierigkeit: {self.difficulty}",
            f"Speed: {self.player.speed}"
        ]
        y = 15
        for text in texts:
            img = FONT.render(text, True, WHITE)
            screen.blit(img, (WIDTH - img.get_width() - 20, y))
            y += 31

    def draw(self):
        self.starfield.draw()
        self.player.draw()
        for b in self.bullets:
            b.draw()
        for b in self.enemy_bullets:
            b.draw()
        for item in self.items:
            item.draw()
        for enemy in self.enemies:
            enemy.draw()
        if self.boss:
            self.boss.draw()
        for p in self.particles:
            p.draw()
        for t in self.texts:
            t.draw()
        self.draw_ui()
        draw_touch_controls()

class Shop:
    def __init__(self, game):
        self.game = game
        self.options = [
            {"name": "+1 Max-Leben", "cost": 10, "action": "life"},
            {"name": "Schneller schießen", "cost": 12, "action": "shoot"},
            {"name": "Schiff schneller", "cost": 10, "action": "speed"},
            {"name": "Schild kaufen", "cost": 8, "action": "shield"},
        ]

    async def run(self):
        reset_touch_controls()
        while True:
            self.game.starfield.update()
            self.game.starfield.draw()

            draw_text_center("SHOP", BIG_FONT, YELLOW, 90)
            draw_text_center(f"Du hast {self.game.coins} Münzen", FONT, WHITE, 160)
            draw_text_center("Klicke ein Upgrade oder WEITER", SMALL_FONT, (190, 220, 255), 195)

            mouse = pygame.mouse.get_pos()
            rects = []

            y = 245
            for opt in self.options:
                rect = pygame.Rect(WIDTH // 2 - 180, y, 360, 55)
                affordable = self.game.coins >= opt["cost"]
                color = (50, 150, 90) if affordable else (80, 80, 90)
                if rect.collidepoint(mouse) and affordable:
                    color = (80, 220, 130)
                pygame.draw.rect(screen, color, rect, border_radius=12)
                pygame.draw.rect(screen, WHITE, rect, 2, border_radius=12)
                label = FONT.render(f"{opt['name']}  -  {opt['cost']} Münzen", True, WHITE)
                screen.blit(label, (rect.centerx - label.get_width() // 2, rect.centery - label.get_height() // 2))
                rects.append((rect, opt))
                y += 70

            continue_rect = pygame.Rect(WIDTH // 2 - 130, y + 20, 260, 60)
            draw_button(continue_rect, "WEITER", mouse)

            pygame.display.flip()
            clock.tick(FPS)
            await asyncio.sleep(0)

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    raise SystemExit

                if event.type == pygame.MOUSEBUTTONDOWN:
                    if continue_rect.collidepoint(event.pos):
                        self.game.shop_open = False
                        return

                    for rect, opt in rects:
                        if rect.collidepoint(event.pos) and self.game.coins >= opt["cost"]:
                            self.game.coins -= opt["cost"]
                            if opt["action"] == "life":
                                self.game.player.max_lives = min(9, self.game.player.max_lives + 1)
                                self.game.player.heal(1)
                            elif opt["action"] == "shoot":
                                self.game.shoot_delay = max(55, self.game.shoot_delay - 15)
                            elif opt["action"] == "speed":
                                self.game.player.speed_bonus = min(12, self.game.player.speed_bonus + 2)
                            elif opt["action"] == "shield":
                                self.game.player.shield = True
                                self.game.player.shield_time = 900

async def start_menu(starfield):
    while True:
        starfield.update()
        starfield.draw()

        draw_text_center("GALAXY SURVIVAL", TITLE_FONT, CYAN, 115)
        draw_text_center("Asteroiden Shooter Deluxe", FONT, WHITE, 195)
        draw_text_center("A/D bewegen  •  Leertaste schießen  •  Shift Dash", SMALL_FONT, (190, 220, 255), 235)

        mouse = pygame.mouse.get_pos()
        start_rect = pygame.Rect(WIDTH // 2 - 130, 320, 260, 65)
        quit_rect = pygame.Rect(WIDTH // 2 - 130, 405, 260, 65)

        draw_button(start_rect, "SPIELEN", mouse)
        draw_button(quit_rect, "BEENDEN", mouse)

        pygame.display.flip()
        clock.tick(FPS)
        await asyncio.sleep(0)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                raise SystemExit
            if event.type == pygame.MOUSEBUTTONDOWN:
                if start_rect.collidepoint(event.pos):
                    return
                if quit_rect.collidepoint(event.pos):
                    pygame.quit()
                    raise SystemExit

async def pause_screen(game):
    reset_touch_controls()
    while True:
        game.draw()
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 150))
        screen.blit(overlay, (0, 0))
        draw_text_center("PAUSE", BIG_FONT, WHITE, HEIGHT // 2 - 60)
        draw_text_center("Taste P oder Bildschirm antippen zum Weiterspielen", FONT, WHITE, HEIGHT // 2 + 10)
        pygame.display.flip()
        clock.tick(FPS)
        await asyncio.sleep(0)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                raise SystemExit
            if event.type == pygame.KEYDOWN and event.key == pygame.K_p:
                reset_touch_controls()
                return
            if event.type in (pygame.FINGERDOWN, pygame.MOUSEBUTTONDOWN):
                reset_touch_controls()
                return

async def game_over_screen(game):
    reset_touch_controls()
    while True:
        game.starfield.update()
        game.starfield.draw()

        draw_text_center("GAME OVER", BIG_FONT, RED, 135)
        draw_text_center(f"Punkte: {game.score}", FONT, WHITE, 230)
        draw_text_center(f"Highscore: {game.highscore}", FONT, YELLOW, 265)
        draw_text_center(f"Level erreicht: {game.level}", FONT, GREEN, 300)

        mouse = pygame.mouse.get_pos()
        restart_rect = pygame.Rect(WIDTH // 2 - 140, 390, 280, 65)
        menu_rect = pygame.Rect(WIDTH // 2 - 140, 475, 280, 65)

        draw_button(restart_rect, "NEUSTART", mouse)
        draw_button(menu_rect, "MENÜ", mouse)

        pygame.display.flip()
        clock.tick(FPS)
        await asyncio.sleep(0)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                raise SystemExit

            if event.type == pygame.MOUSEBUTTONDOWN:
                if restart_rect.collidepoint(event.pos):
                    return "restart"
                if menu_rect.collidepoint(event.pos):
                    return "menu"

async def main():
    game = Game()
    await start_menu(game.starfield)

    shop = Shop(game)
    running = True

    while running:
        clock.tick(FPS)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                raise SystemExit
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_p:
                    await pause_screen(game)

            handle_touch_event(event)

            if event.type in (pygame.FINGERDOWN, pygame.MOUSEBUTTONDOWN):
                if event.type == pygame.FINGERDOWN:
                    tap_pos = (event.x * WIDTH, event.y * HEIGHT)
                else:
                    tap_pos = event.pos
                if PAUSE_BTN.collidepoint(tap_pos):
                    await pause_screen(game)

        if game.shop_open:
            await shop.run()

        game.update()
        game.draw()

        if game.player.lives <= 0:
            result = await game_over_screen(game)
            if result == "restart":
                game.reset_all()
                shop = Shop(game)
            else:
                game.reset_all()
                shop = Shop(game)
                await start_menu(game.starfield)

        pygame.display.flip()
        await asyncio.sleep(0)

    pygame.quit()

asyncio.run(main())
