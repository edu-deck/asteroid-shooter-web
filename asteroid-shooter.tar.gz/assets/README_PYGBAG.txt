PYGBAG VERSION - Asteroiden Shooter: Galaxy Survival

1) Installieren:
   python -m pip install pygbag

2) Ordner öffnen, der diese Datei und main.py enthält.

3) Im Terminal starten:
   pygbag main.py

   Falls das nicht klappt, nimm:
   python -m pygbag main.py

4) Danach öffnet pygbag normalerweise eine lokale Browser-Adresse.
   Wenn nicht, kopiere die angezeigte localhost-Adresse in deinen Browser.

Steuerung:
A / D oder Pfeiltasten = bewegen
Leertaste halten = schießen
Shift = Dash
P = Pause

Hinweis:
Diese Version ist browserfreundlich gemacht: Die Hauptschleifen benutzen async/await,
damit pygbag im Browser nicht einfriert.
